
from airflow.models import DAG

from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.utils.task_group import TaskGroup

from datetime import datetime

from RF44 import read_data

from RF44 import fitdata

from RF44 import predictions
            
from RF44 import save_data
#from XGBoost4 import storedata



default_args= {
    'owner': 'Alex',
    'email_on_failure': False,
    'email': ['alex@mail.com'],
    'start_date': datetime(2022, 12, 1)
}

with DAG(
    "DAGGRF44",
    description='ML pipeline example',
    schedule_interval='@daily',
    default_args=default_args, 
    catchup=False) as dag:

    
      # task: 1
    with TaskGroup('readdata') as readdata:

        # task: 1.1
        readdata = PythonOperator(
            task_id='readdata',
            python_callable=read_data
        )


    # task: 2
    with TaskGroup('fit_data') as fit_data:

        # task: 2.1
        traindata = PythonOperator(
            task_id='traindata',
            python_callable=fitdata
        )

      
    # task: 3
    with TaskGroup('prediction') as prediction:

        # =======
        # task: 3.1        
        pred = PythonOperator(
            task_id='pred',
            python_callable=predictions
        )
        
    # task: 4
    with TaskGroup('save') as saveresult:

        # =======
        # task: 4.1        
        saving_results = PythonOperator(
            task_id='saving_results',
            python_callable=save_data
        )
      

    readdata >> fit_data >> prediction >> saveresult
