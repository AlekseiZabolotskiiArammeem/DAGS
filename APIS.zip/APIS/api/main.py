import os
import tempfile

import boto3
import catboost as cb
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from tortoise.contrib.fastapi import register_tortoise

import services
from config import get_settings
from schemas import OrderPredictIn, HealthCheck, OrderPredictOut

settings = get_settings()

app = FastAPI(title='Predict ETA service', version='0.0.1',
              description="Copyright © 2019-2022 Aram Meem Company Limited. All Rights Reserved.",
              contact={"email": "admin@arammeem.com"})

DB_URL = f"postgres://{settings.db_user}:{settings.db_password}@{settings.db_host}:{settings.db_port}/{settings.db_name}"


# loading model data
#s3_client = boto3.client('s3')
#tf = tempfile.NamedTemporaryFile(mode='wb', delete=False)
#s3_client.download_file(settings.s3_bucket, settings.s3_path, tf.name)
#cbr = cb.CatBoostRegressor()
#cbr.load_model(tf.name)
#os.unlink(tf.name)


@app.get('http://localhost:8080/home')
async def get_predict_order_eta(data: OrderPredictIn):
    """Get order predict ETA in seconds"""

    s3_client.download_file(settings.s3_bucket, settings.s3_path, tf.name)
    with open(tf.name) as f:
        data = json.load(f)

    return JSONResponse({'predicted_eta': data})


@app.get('/healthcheck', response_model=HealthCheck,
         responses={500: {"model": HealthCheck, "content": {"application/json": {"example": {"check": False}}}}},
         tags=['Healthcheck'])
def healthcheck():
    """Healthcheck endpoint"""
    return JSONResponse({'check': True})
    
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True, log_level='debug')
