#
#   Copyright © 2019-2022 Aram Meem Company Limited. All Rights Reserved.
#

from pydantic import BaseSettings, Field
from functools import lru_cache


class Settings(BaseSettings):
    db_host: str = Field(..., env='DB_HOST')
    db_name: str = Field(..., env='DB_NAME')
    db_port: int = Field(..., env='DB_PORT')
    db_user: str = Field(..., env='DB_USER')
    db_password: str = Field(..., env='DB_PASSWORD')
    s3_path: str = Field(..., env='S3_PATH')
    s3_bucket: str = Field(..., env='S3_BUCKET')

    class Config:
        env_prefix = ""
        env_file = "../.env"
        env_file_encoding = 'utf-8'
        case_sensitive = False


@lru_cache()
def get_settings():
    return Settings()
